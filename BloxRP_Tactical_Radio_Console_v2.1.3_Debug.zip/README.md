# BloxRP - Tactical Radio & RP Console v2.1.2

Google hesaplı Firebase Authentication sürümü. Mobil-first cyberpunk telsiz arayüzü, Realtime Database chat, XP/rütbe sistemi, RP timer, presence ve admin terminali içerir.

## Değişiklikler (v2.1.2 - WebIntoApp Fix)
- Firebase SDK artık **yerel** (`vendor/` klasöründe). CDN'e ihtiyaç yok → WebIntoApp / WebView'da yüklenme sorunu çözüldü.
- SDK sürümü 10.14.1'e güncellendi.
- Boot sırasında 6 saniyelik güvenlik zamanlayıcısı eklendi → login ekranı asla takılı kalmaz.
- `forceShowLogin()` ile hata durumunda bile login modalı zorunlu açılır.
- WebView / WebIntoApp (APK) ortamlarında Google Sign-In önce **redirect** kullanır (popup yerine).
- Hata mesajları daha anlaşılır hale getirildi.

## Değişiklikler (v2.1)
- Firebase config artık **hardcoded** — kurulum ekranı zorunlu değil, uygulama açılınca otomatik bağlanır.
- Boot ekranı ("Firebase bağlantısı hazırlanıyor...") takılma sorunu giderildi.
- `database.rules.json` içindeki `founder_uid` syntax hatası düzeltildi (`.read` / `.write`).
- Google login akışı güçlendirildi; auth henüz hazır değilse otomatik yeniden init denenir.
- 4 saniye içinde auth state gelmezse login kapısı otomatik açılır (sonsuz boot engellendi).

## Google Login kurulumu
1. Firebase Console > Authentication > Sign-in method → **Google** sağlayıcısını etkinleştir.
2. Authentication > Settings > Authorized domains → uygulamanın HTTPS alan adını (ve `localhost`) ekle.
3. Realtime Database oluştur ve `database.rules.json` kurallarını uygula.
4. Google ile giriş yap. İlk başarılı Google hesabı `system/founder_uid` claim eder → otomatik Kurucu + admin olur.

## Önemli
- Config istemci tarafında görünür; gerçek güvenlik Authentication + Database Rules ile sağlanır.
- WebView / APK'da redirect, tarayıcıda popup öncelikli.
- APK WebView ortamlarında Google OAuth kısıtlanabilir; native Firebase Google Sign-In önerilir.
- Demo moda her zaman geçilebilir (login ekranından).

## Kanallar
`Hepsi`, `Asker`, `Tetik`, `Yonetim`

## XP
Mesaj başına +15 XP. Eşik `seviye x 100`.

## Admin / Kurucu
İlk Google login yapan hesap `system/founder_uid` alanını transaction ile claim eder.
Bu hesap `admin: true`, `customRank: "Kurucu"`, `faction: "Yonetim"` alır.
